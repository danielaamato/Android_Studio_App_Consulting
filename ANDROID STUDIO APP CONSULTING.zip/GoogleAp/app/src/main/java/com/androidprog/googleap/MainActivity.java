package com.androidprog.googleap;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button bResposta1;
    private Button bResposta2;
    private TextView question;
    private TextView welcome;
    int id = 0;
    private View rootView;
    private int ranking = 0;

    private Questions[] questions = {
            new Questions("¿Qué es más buscado en Google?\n\nA) Netlix \nB) HBOMAX", new String[]{"A", "B"}, 1),
            new Questions("¿Qué es más buscado en Google?\n\nA) Netflix \nC) Prime", new String[]{"A", "C"}, 1)
    };

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rootView = getWindow().getDecorView().getRootView();
        rootView.setBackgroundColor(Color.CYAN);

        welcome = findViewById(R.id.textView2);

        question = findViewById(R.id.pregunta);

        bResposta1 = findViewById(R.id.bResposta1);
        bResposta2 = findViewById(R.id.bResposta2);

        bResposta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRespuestaClick(v);
            }
        });

        bResposta2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRespuestaClick(v);
            }
        });

        showQuestion();
    }

    public void showQuestion()
    {
        Questions preguntaActual = questions[id];
        question.setText(preguntaActual.getQuestion());

        if (id == 0)
        {
            bResposta1.setText(preguntaActual.getOption()[0]);
            bResposta2.setText(preguntaActual.getOption()[1]);
        }
        else if (id == 1)
        {
            bResposta1.setText(preguntaActual.getOption()[0]);
            bResposta2.setText(preguntaActual.getOption()[1]);
        }
    }

    @SuppressLint("NonConstantResourceId")
    public void onRespuestaClick(View view)
    {
        int idbutton = view.getId();
        int respuestaSeleccionada = 0;

        switch (idbutton)
        {
            case R.id.bResposta1:
                respuestaSeleccionada = 1;
                break;
            case R.id.bResposta2:
                respuestaSeleccionada = 2;
                break;
        }

        if (questions[id].getCorrect() == respuestaSeleccionada)
        {
            id++;
            ranking += 100;

            if (id == questions.length)
            {
                Toast.makeText(this, "¡Muy bien las acertaste todas!", Toast.LENGTH_SHORT).show();
                finish();
            }
            else
            {
                Toast.makeText(this, "¡Correcto!", Toast.LENGTH_SHORT).show();

                showQuestion();
            }
        }
        else
        {
            Toast.makeText(this, "¡Respuesta erronea, has perdido!", Toast.LENGTH_SHORT).show();
            finish();
        }

        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(ranking/(questions.length));
    }
}